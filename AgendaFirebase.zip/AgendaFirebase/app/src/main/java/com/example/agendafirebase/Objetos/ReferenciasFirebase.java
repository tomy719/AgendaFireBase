package com.example.agendafirebase.Objetos;

public class ReferenciasFirebase {
    final static public String URL_DATABASE = "https://appfirebase-da132-default-rtdb.firebaseio.com/";
    final static public String DATABASE_NAME = "agenda";
    final static public String TABLE_NAME = "contactos";
}

